import React from 'react'
import { shallow } from 'enzyme'
import SamplePage from '.'

it('renders', () => {
  shallow(<SamplePage />)
})
